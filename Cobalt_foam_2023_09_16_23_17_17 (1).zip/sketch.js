function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(220);
  ellipse(50,50,80,80);
  point(30,20);
  point(85,20);
  stroke('purple');
  strokeWeight(10);
  point(85,75);
  point(30,75);
  line(30,20,85,75);
  stroke(126);
  line(85,20,85,75);
  rect(30,20,55,55,20)
}